# if arcade.check_for_collision(self.stinger, self.basic_cube):
#     self.basic_cube.alpha = 0
#     if time.time() - self.cube_apper_time > 1:
#     time.sleep(1)
# self.basic_cube.alpha = 255
# self.stinger.center_x = 1370
# self.attempts += 1


# if self.angle <= -LIMIT_ANGLE:
#     self.angle = -LIMIT_ANGLE
#     self.change_angle = 0

# arcade.draw_rectangle_filled(
#     ZONE_X_5 + ZONE_WIDTH_5 / 2,
#     ZONE_Y_5 + ZONE_HEIGHT_5 / 2,
#     ZONE_WIDTH_5,
#     ZONE_HEIGHT_5,
#     arcade.color.LIGHT_BLUE)

# arcade.draw_rectangle_filled(
#     ZONE_X_4 + ZONE_WIDTH_4 / 2,
#     ZONE_Y_4 + ZONE_HEIGHT_4 / 2,
#     ZONE_WIDTH_4,
#     ZONE_HEIGHT_4,
#     arcade.color.LIGHT_BLUE)

# arcade.draw_rectangle_filled(
#     ZONE_X_3 + ZONE_WIDTH_3 / 2,
#     ZONE_Y_3 + ZONE_HEIGHT_3 / 2,
#     ZONE_WIDTH_3,
#     ZONE_HEIGHT_3,
#     arcade.color.LIGHT_BLUE)

# arcade.draw_rectangle_filled(
#     ZONE_X_2 + ZONE_WIDTH_2 / 2,
#     ZONE_Y_2 + ZONE_HEIGHT_2 / 2,
#     ZONE_WIDTH_2,
#     ZONE_HEIGHT_2,
#     arcade.color.LIGHT_BLUE)
#
# arcade.draw_rectangle_filled(
#     ZONE_X_1 + ZONE_WIDTH_1 / 2,
#     ZONE_Y_1 + ZONE_HEIGHT_1 / 2,
#     ZONE_WIDTH_1,
#     ZONE_HEIGHT_1,
#     arcade.color.LIGHT_YELLOW)
